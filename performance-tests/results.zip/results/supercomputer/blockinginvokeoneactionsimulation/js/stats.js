var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "20633",
        "ok": "20633",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "74",
        "ok": "74",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "857",
        "ok": "857",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "267",
        "ok": "267",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "77",
        "ok": "77",
        "ko": "-"
    },
    "percentiles1": {
        "total": "253",
        "ok": "253",
        "ko": "-"
    },
    "percentiles2": {
        "total": "303",
        "ok": "303",
        "ko": "-"
    },
    "percentiles3": {
        "total": "411",
        "ok": "411",
        "ko": "-"
    },
    "percentiles4": {
        "total": "521",
        "ok": "521",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 20629,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 4,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "361.982",
        "ok": "361.982",
        "ko": "-"
    }
},
contents: {
"req_create-action-1bc73": {
        type: "REQUEST",
        name: "Create action",
path: "Create action",
pathFormatted: "req_create-action-1bc73",
stats: {
    "name": "Create action",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "119",
        "ok": "119",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "119",
        "ok": "119",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "119",
        "ok": "119",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "119",
        "ok": "119",
        "ko": "-"
    },
    "percentiles2": {
        "total": "119",
        "ok": "119",
        "ko": "-"
    },
    "percentiles3": {
        "total": "119",
        "ok": "119",
        "ko": "-"
    },
    "percentiles4": {
        "total": "119",
        "ok": "119",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.018",
        "ok": "0.018",
        "ko": "-"
    }
}
    },"req_warm-containers-a6348": {
        type: "REQUEST",
        name: "Warm containers up",
path: "Warm containers up",
pathFormatted: "req_warm-containers-a6348",
stats: {
    "name": "Warm containers up",
    "numberOfRequests": {
        "total": "1605",
        "ok": "1605",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "84",
        "ok": "84",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "857",
        "ok": "857",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "316",
        "ok": "316",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "113",
        "ok": "113",
        "ko": "-"
    },
    "percentiles1": {
        "total": "295",
        "ok": "295",
        "ko": "-"
    },
    "percentiles2": {
        "total": "362",
        "ok": "362",
        "ko": "-"
    },
    "percentiles3": {
        "total": "559",
        "ok": "559",
        "ko": "-"
    },
    "percentiles4": {
        "total": "693",
        "ok": "693",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1602,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 3,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "28.158",
        "ok": "28.158",
        "ko": "-"
    }
}
    },"req_invoke-action-04fbe": {
        type: "REQUEST",
        name: "Invoke action",
path: "Invoke action",
pathFormatted: "req_invoke-action-04fbe",
stats: {
    "name": "Invoke action",
    "numberOfRequests": {
        "total": "19026",
        "ok": "19026",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "74",
        "ok": "74",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "819",
        "ok": "819",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "263",
        "ok": "263",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "72",
        "ok": "72",
        "ko": "-"
    },
    "percentiles1": {
        "total": "250",
        "ok": "250",
        "ko": "-"
    },
    "percentiles2": {
        "total": "299",
        "ok": "299",
        "ko": "-"
    },
    "percentiles3": {
        "total": "400",
        "ok": "400",
        "ko": "-"
    },
    "percentiles4": {
        "total": "493",
        "ok": "493",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 19025,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 1,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "333.789",
        "ok": "333.789",
        "ko": "-"
    }
}
    },"req_delete-action-7c03e": {
        type: "REQUEST",
        name: "Delete action",
path: "Delete action",
pathFormatted: "req_delete-action-7c03e",
stats: {
    "name": "Delete action",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "194",
        "ok": "194",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "194",
        "ok": "194",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "194",
        "ok": "194",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "194",
        "ok": "194",
        "ko": "-"
    },
    "percentiles2": {
        "total": "194",
        "ok": "194",
        "ko": "-"
    },
    "percentiles3": {
        "total": "194",
        "ok": "194",
        "ko": "-"
    },
    "percentiles4": {
        "total": "194",
        "ok": "194",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.018",
        "ok": "0.018",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
